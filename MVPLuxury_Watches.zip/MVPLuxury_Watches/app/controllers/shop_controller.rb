class ShopController < ApplicationController
  def shop
  end
end

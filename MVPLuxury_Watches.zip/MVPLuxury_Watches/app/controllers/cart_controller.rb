class CartController < ApplicationController
  def cart
  end
end

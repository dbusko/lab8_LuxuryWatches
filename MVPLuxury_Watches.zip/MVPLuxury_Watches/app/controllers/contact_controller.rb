class ContactController < ApplicationController
  def contact
  end
end

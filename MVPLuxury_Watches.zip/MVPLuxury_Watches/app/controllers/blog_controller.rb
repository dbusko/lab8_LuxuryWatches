class BlogController < ApplicationController
  def blog
  end
end

class SproductController < ApplicationController
  def sproduct
  end
end
